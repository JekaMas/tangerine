# Tasks

- [ ] Obtain and hash the current source/spec snapshot.
- [ ] Resolve each of the 20 scoped decision groups.
- [ ] Reconcile all 33 engineering candidate entries with active contracts.
- [ ] Complete the internal operation payload bindings and database field dictionary.
- [ ] Complete every enum/null cross-field rule against the active schemas.
- [ ] Complete release-specific source parser tables from actual documentation.
- [ ] Preserve the full 122-leaf and 42-metric scope.
- [ ] Integrate only approved policy choices.
- [ ] Execute the official OpenSpec and current contract checks.
- [ ] Obtain actual source, review, provider, gold, and runtime evidence under their separate gates.
- [ ] Close each GAP only after its specific closure criterion is satisfied.
