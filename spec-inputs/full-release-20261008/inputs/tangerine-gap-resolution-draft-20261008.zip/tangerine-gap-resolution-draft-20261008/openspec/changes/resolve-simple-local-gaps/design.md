# Integration design

The current reports take precedence over historical account and provider assumptions.
The domain math remains separate from semantic decisions and human evidence.
The candidate documents identify exact data and failure boundaries.

Read docs/authority-and-integration.md from the package root.
Read audit/gap-status.json before marking a gap closed.
Every policy group remains unapproved until a real owner response identifies its scope.
The current repository must supply field-level contracts, active source profiles, and version compatibility.
