# Resolve the simple-local definition gaps

## Why

The two supplied reports identify 53 grouped definition gaps.
The current repository has newer scope and provider changes than the available v6 ZIP.
A direct overwrite would risk restoring superseded requirements.

## What Changes

- Propose exact identity, semantic normalization, math transport, and result reference rules.
- Propose local object/DB consistency, lease recovery, and release procedures.
- Supply scoped policy questions and proposed linguistic artifacts.
- Preserve every open source, approval, implementation, and evidence obligation.

## Capabilities

### New Capabilities

- gap-resolution-integrity: Preserve exact decisions, versions, and unfinished evidence during integration.

### Modified Capabilities

The current repository must supply the exact active capability names before delta integration.
This package does not invent names for missing current contracts.

## Impact

The proposal affects contracts, policies, source manifests, provider adapters, and local workflow specifications.
No current source code, runtime, dataset, or approved record changes in this package.
