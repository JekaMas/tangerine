## ADDED Requirements

### Requirement: Current local scope remains authoritative
The integration MUST preserve the current account-free local scope.
Historical artifacts MUST NOT restore removed tenant, account, or access-role behavior.

#### Scenario: A historical artifact names tenant ownership
- **GIVEN** the current local contract requires workspace_id=local
- **WHEN** an older schema names tenant_id
- **THEN** integration uses the current local contract
- **AND** the mismatch remains in the migration record

#### Scenario: A newer profile is absent
- **GIVEN** a report references a configurable DeepSeek profile that is not supplied
- **WHEN** an agent prepares the integration
- **THEN** the agent requests the actual profile
- **AND** it does not restore the old default or invent a replacement

### Requirement: Policy approval is scoped and genuine
The integration MUST keep each policy proposal unapproved until a real owner decision resolves that scope.
The integration MUST NOT invent approval evidence.

#### Scenario: A scoped decision is present
- **GIVEN** the owner approves an identified proposal for one GAP
- **WHEN** the decision is recorded
- **THEN** its source statement and artifact version identify that exact change
- **AND** unrelated GAP proposals remain pending

#### Scenario: A proposal contains an empty approval list
- **GIVEN** a proposal file contains no real owner decision
- **WHEN** the integration checks publication authority
- **THEN** the proposal cannot count as an approved policy

### Requirement: Exact math has exact inputs and transport
The scorer MUST use validated normalized decisions and exact arithmetic.
The scorer MUST NOT use a rounded display or a model-supplied grade as an arithmetic input.

#### Scenario: A semantic decision is unresolved
- **GIVEN** an unresolved decision can change a metric
- **WHEN** the application prepares the result
- **THEN** final aggregate metrics remain unavailable
- **AND** supported item evidence remains explicitly provisional

#### Scenario: Only a display string exists
- **GIVEN** a value has no exact fraction or sufficient statistics
- **WHEN** the application attempts a pooled score
- **THEN** it rejects the value as a score input

### Requirement: Evidence remains separate from definitions
The integration MUST distinguish a defined rule from an executed observation.
A drafted contract MUST NOT establish acquired data, human review, or provider qualification.

#### Scenario: A source has no acquired bytes
- **GIVEN** only a paper or vendor page identifies the source
- **WHEN** the source manifest is inspected
- **THEN** acquired asset counts remain unsupported
- **AND** no asset hashes or permissions are invented

#### Scenario: A schema proposal is structurally valid
- **GIVEN** the JSON Schema meta-schema accepts the proposal
- **WHEN** the gap closure is assessed
- **THEN** structural validity does not prove semantic completeness or runtime behavior
