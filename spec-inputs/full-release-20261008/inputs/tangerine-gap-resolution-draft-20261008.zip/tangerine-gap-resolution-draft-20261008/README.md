# Tangerine gap-resolution draft

This package proposes resolutions for the 53 grouped gaps in the two supplied reports.
It does not replace the current Tangerine repository or the historical v6 archive.
No gap is declared fully closed. The current source snapshot is missing.

## Current scope

The product uses one local workspace with a web interface and provider keys.
It has no user accounts, access roles, tenants, or public API setup.
Preparation, review, listening, free-form answers, synchronous evaluation, and saved results remain in scope.
All 122 taxonomy leaves and all 42 inherited metric IDs remain in scope.
The requested synthetic audio is a product output. Fake provider responses and invented evidence remain forbidden.

## Read order

1. Read DECISIONS.md for the 20 scoped choices.
2. Read docs/math-and-judgments.md for the exact counting and transport proposals.
3. Read docs/runtime-and-storage.md for state, storage, and recovery proposals.
4. Read docs/linguistic-policies.md and the candidate alias registry.
5. Read audit/gap-status.json for the actual unfinished status.

## What is present

The package includes 33 engineering candidate entries and 20 unapproved decision groups.
It includes a proposed bilingual registry for 122 leaves and 16 ancestors.
It includes four closed JSON Schema proposals, a linguistic-audit prompt, and an exact inherited formula map.
It contains no fabricated exercises, audio, teacher answers, identities, consents, approvals, or provider measurements.

## Required input

Supply the current source/spec archive at reported commit 203c1f1 or later.
The reports name current files that are absent from v6, including the simple-local and configurable DeepSeek overlays.
A repository URL and accessible branch/commit can supply the same source.
Exclude secrets, personal records, node_modules, virtual environments, and corpus bytes from that code archive.
Provide source release documentation separately when its parser or rights contract is needed.

## Status

The attached reports are the current scope source.
The historical v6 registry supplies preserved formulas and IDs only.
The package does not claim full current-schema coverage, a complete database migration, or a running application.
The proposal text uses short technical English. No full ASD-STE100 dictionary compliance verdict was made.
See audit/inspection.json for the checks actually performed.
