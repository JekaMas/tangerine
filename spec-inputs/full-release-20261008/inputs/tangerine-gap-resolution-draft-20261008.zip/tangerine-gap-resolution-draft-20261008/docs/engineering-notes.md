# Evidence and acceptance contracts

These definitions are proposals for the existing local product.
They do not create reviewer identities, observations, consents, or test data.

## GAP-010: Blind review

A blind observation stores observation_id, review_id, final_audio_sha256, interval_start_sample, interval_end_sample, and original_note.
It also stores proposed taxonomy IDs, observed status, uncertainty, and any observed phonetic transcription.
Unknown categories or observed IPA remain null or an explicit unresolved set.
An observation ID does not contain a planned unit ID.
A review submission stores the full observation-set hash, person reference, qualification references, and server timestamp.
After submission, the observation set is immutable.
Only a separate disclosure operation reveals the planned key and records its exact hash.
Post-key correspondence records map observation IDs to planned units. Keep unmapped discoveries and missed planned units.
No correspondence can alter the original independent observation.

## GAP-012: Teacher-answer gold

A gold record binds exact answer bytes/hash, case/audio/key hashes, task components, taxonomy, and split manifest.
Each rater supplies independent clause spans, stance, attachments, categories, target mappings, correction judgments, rationale judgments, and uncertainty.
Store each rater's submission before showing model output or another rater's labels.
An adjudication references the separate original label sets and gives a reason for every changed decision.
Do not overwrite original rater labels with the consensus record.
A real answer can be partial, vague, contradictory, repeated, retracted, false, or plausible off-key.
A class label does not authorize the application to invent a representative teacher answer.
An absent class is a coverage gap, not a synthetic fixture opportunity.

## GAP-038: Target qualification

For each taxonomy leaf, require a qualification record for every supported profile/locale/voice/target combination.
Store the leaf ID, operator plan, target bounds, public context, planned controls, and exact observable acceptance criteria.
Store the actual final audio hash, all render receipts, measurements, two person-bound observations, and the qualification result.
Use untested, passed, failed, or review_required. Only actual evidence can change untested to passed.
A passed profile for one target does not qualify every target in the same family.
A provider/model/voice/prompt/compiler change invalidates qualification for the changed combination.
A server-side model alias update cannot always be identified from its name alone.
Record the returned model identifier and observed drift. Do not claim an immutable snapshot when the provider does not expose one.
Canary executions use approved real inputs and preserve every output. They do not synthesize fake measurements.
Retain a failed target in scope. Three failed render candidates do not remove it from the product.
The exact catalog for all combinations still needs the current blueprint and capability registries.

## GAP-049: Time and playback

An explicit start operation commits started_at from the DB clock and freezes the selected exercise version.
Repeated start requests with the same idempotency key return the existing attempt and original timestamp.
A new attempt has a new identity. A browser reload is not a new attempt.
Submission stores submitted_at once with the original answer.
Do not use a browser-provided wall clock for the elapsed result.
Store client event ID, attempt ID, final audio hash, event type, reported playhead sample, and accepted_at for playback events.
The permitted event types are play, pause, seek, and ended. Only play increments replay_count.
Require the playhead to be within the audio sample count.
Deduplicate `(attempt_id,event_id)` before counting. The same ID with changed content is a conflict.
Late events can be retained with a late flag but cannot change frozen telemetry after submission.
Do not infer a play from a media GET. Range requests and downloads do not prove playback.
These values remain descriptive and cannot contribute to teacher skill scores.

## GAP-050: Heldout protocol

Freeze the corpus manifest, independent labels, all prompts, schemas, source mappings, model bindings, methods, and scoring policies before evaluation.
Preserve the current thresholds. This draft does not approve or empirically validate them.
For each reporting domain, use its actual eligible population. Do not redistribute unknown-domain errors into convenient strata.
Compute mapping precision and coverage on the same frozen population.
Keep separate minimum denominators for mapping decisions and correction attempts.
A lack of sufficient real data produces insufficient_evidence, not a pass on a smaller subset.
Use the three-run pairwise estimator in math-and-judgments.md. Record all three actual responses and their hashes.
Any change made after inspection of holdout results requires a new undisclosed holdout or explicit disclosure of reuse.

The mandatory critical-case classes are:

- Correct detection with a wrong category.
- Correct detection with a wrong correction.
- A plausible correction absent from the key.
- A possible unlisted error.
- An ambiguous repeated expression.
- Exact duplicates and compatible fragments.
- Explicit retractions and unretracted contradictions.
- Permitted dialect or register variants.
- Missing requested explanations.
- Clean audio with no true errors.
- Empty teacher answers with actual errors.
- Fabricated quote offsets or unknown reference IDs.
- Wrong-case evidence and changed audio hashes.
- Provider refusal, incomplete output, and unavailable commentary.

These are required coverage classes, not created test cases.
A test using an artificial input needs the owner's scoped approval before creation and execution.
Safety tests that attempt key disclosure apply to activity projections, not deleted user roles.
No login, tenant, or cross-account test is introduced under the removed GAP-005/GAP-006 scope.
