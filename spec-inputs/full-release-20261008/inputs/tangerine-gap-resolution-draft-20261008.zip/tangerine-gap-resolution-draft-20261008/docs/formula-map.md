# Formula locations

The source is the preserved v6 registry. The supplied reports state that all these formulas remain present.
The current source must confirm their hashes before integration. No formula changed in this proposal.

| ID | Name | Preserved formula | Proposed output location |
|---|---|---|---|
| `detection.precision` | Detection precision | `TP/(TP+FP)` | `score.metrics` |
| `detection.recall` | Detection recall | `TP/G` | `score.metrics` |
| `detection.f1` | Detection F1 | `2*TP/(2*TP+FP+FN)` | `score.metrics` |
| `detection.miss_rate` | Miss rate | `FN/G` | `score.metrics` |
| `detection.false_discovery_rate` | False discovery rate | `FP/(TP+FP)` | `score.metrics` |
| `classification.coverage` | Explicit category coverage | `LC/TP` | `score.metrics` |
| `classification.family_accuracy` | Reporting-domain accuracy | `LF/LC` | `score.metrics` |
| `classification.exact_accuracy` | Exact category accuracy | `LE/LC` | `score.metrics` |
| `classification.hierarchical_accuracy` | Hierarchical category accuracy | `H/LC` | `score.metrics` |
| `classification.hierarchical_recall` | Overall hierarchical classification credit | `H/G` | `score.metrics` |
| `correction.attempt_rate` | Correction attempt rate | `CA/TC` | `score.metrics` |
| `correction.strict_accuracy` | Strict correction accuracy | `CK/CA` | `score.metrics` |
| `correction.graded_accuracy` | Graded correction accuracy | `CQ/CA` | `score.metrics` |
| `correction.strict_recall` | Strict correction recall | `CK/GC` | `score.metrics` |
| `correction.graded_recall` | Graded correction recall | `CQ/GC` | `score.metrics` |
| `correction.assertion_precision` | Correction assertion precision | `CK/(CA+FC)` | `score.metrics` |
| `explanation.coverage` | Explanation coverage | `EA/TE` | `score.metrics` |
| `explanation.strict_accuracy` | Strict explanation accuracy | `EK/EA` | `score.metrics` |
| `explanation.graded_accuracy` | Graded explanation accuracy | `EQ/EA` | `score.metrics` |
| `explanation.graded_recall` | Overall explanation credit | `EQ/GE` | `score.metrics` |
| `decoy.overcorrection_rate` | Designated-decoy overcorrection | `DF/D` | `score.metrics` |
| `decoy.unflagged_rate` | Designated-decoy unflagged rate | `(D-DF)/D` | `score.metrics` |
| `decoy.explicit_acceptability_accuracy` | Explicit decoy judgment accuracy | `DA/(DA+DF)` | `score.metrics` |
| `acceptability.explicit_accuracy` | Explicit binary acceptability accuracy | `SA/SN` | `score.metrics` |
| `weighted.precision` | Severity-weighted precision | `WTP/(WTP+WFP)` | `score.metrics` |
| `weighted.recall` | Severity-weighted recall | `WTP/(WTP+WFN)` | `score.metrics` |
| `weighted.f1` | Severity-weighted F1 | `2*WTP/(2*WTP+WFP+WFN)` | `score.metrics` |
| `annotation.agreement` | Raw inter-rater agreement | `agreements/N` | `auxiliary.metrics` |
| `annotation.cohen_kappa` | Cohen kappa | `(Po-Pe)/(1-Pe); Pe=sum_label(p_rater1(label)*p_rater2(label))` | `auxiliary.metrics` |
| `verification.wer` | Unconstrained transcript word error rate | `(substitutions+deletions+insertions)/reference_word_count` | `auxiliary.metrics` |
| `audio.speech_rate_wpm` | Speech rate WPM | `60*spoken_token_count/elapsed_speech_span_seconds` | `auxiliary.metrics` |
| `audio.articulation_rate_wpm` | Articulation rate WPM | `60*spoken_token_count/active_speech_seconds` | `auxiliary.metrics` |
| `audio.pause_ratio` | Internal pause ratio | `internal_silent_seconds/elapsed_speech_span_seconds` | `auxiliary.metrics` |
| `audio.disfluency_density` | Disfluencies per 100 words | `100*reviewed_disfluency_events/spoken_token_count` | `auxiliary.metrics` |
| `evaluation.coverage` | Semantic decision coverage | `resolved_decisions/eligible_decisions` | `auxiliary.metrics` |
| `evaluation.exact_mapping_agreement` | Mapping agreement with adjudicated gold | `identical_claim_to_unit_decisions/eligible_gold_decisions` | `auxiliary.metrics` |
| `telemetry.elapsed_seconds` | Elapsed attempt wall time | `submitted_at-started_at` | `auxiliary.metrics` |
| `telemetry.replay_count` | Audio play-event count | `count(validated_play_events)` | `auxiliary.metrics` |
| `teacher.talk_time` | Teacher talk time | `None` | `auxiliary.metrics` |
| `teacher.pronunciation` | Teacher spoken pronunciation | `None` | `auxiliary.metrics` |
| `teacher.classroom_management` | Classroom management | `None` | `auxiliary.metrics` |
| `teacher.engagement` | Real student engagement | `None` | `auxiliary.metrics` |
