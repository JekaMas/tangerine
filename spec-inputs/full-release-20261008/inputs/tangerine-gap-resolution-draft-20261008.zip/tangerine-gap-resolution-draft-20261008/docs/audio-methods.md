# Audio construction and evidence proposal

These rules target GAP-033, GAP-034, and GAP-037.
GAP-032 determines which requests are hard constraints. GAP-035 and GAP-036 determine linguistic measurements.
Actual compiler schemas and binary locks still need integration with the current source.

## Typed plan

Accept only text, phoneme, pause, and prosody nodes from a closed render-plan schema.
Reject unknown fields and unbound provider capabilities before a call.
Escape XML text and attributes. Do not accept raw SSML, external URLs, entities, or executable commands from a candidate.
A phoneme node has a source text span, a declared alphabet, and a reviewed intended phone string.
A pause has a nonnegative planned duration. It does not carry text or a phone string.
A prosody node has a scoped text/phoneme subtree and only its declared rate, pitch, or volume fields.
A text node cannot carry a hidden phoneme or pause payload.
Reject conflicting nested values instead of choosing the inner or outer value implicitly.

Compile one declared turn at a time under its fixed voice and locale.
Retain turn order. Do not let the provider infer a speaker switch from names in a prompt.
A rate percentage is a synthesis control, not a measured WPM value.
A break duration is an intended pause, not proof of the observed duration.
Save the exact generated SSML privately with its hash.

## Final bytes

Propose one canonical delivered asset: PCM16 mono WAV at 24000 Hz.
Use the same final asset for publication review and browser playback.
Do not silently create an MP3 after the review.
Read PCM from each returned turn and retain each source asset/receipt.
Concatenate in declared order. Add only explicitly planned inter-turn sample gaps.
Do not auto-trim, time-stretch, denoise, crossfade, or compress dynamics.
A uniform gain transform requires a recorded transform and measurement on the resulting final bytes.
Do not use a limiter to hide a target/QC conflict.

Store sample intervals as half-open integer pairs in the final clock.
For an advisory source interval [a,b) in seconds, use floor(a*24000) and ceil(b*24000).
Keep the original unrounded interval and the conversion method.
Do not silently clamp invalid provider intervals into range.
A turn offset is the exact sum of all prior output samples and explicit gap samples.
A later re-encoding creates a different asset and invalidates approval for the changed bytes.

## Mechanical quality

Decode the final asset. Require one finite nonempty mono sample sequence.
For PCM16, normalize sample k as signed_integer(k)/32768.
Measure peak as max(abs(x)). Require peak <= 0.9999 under the inherited policy.
Do not round before comparing a measurement to a boundary.

Use a version-locked implementation of the stated loudness and true-peak methods.
Record executable hash, build configuration, options, and final asset hash.
The relevant ITU method family is BS.1770. The official current listing identifies BS.1770-5.
Source: https://www.itu.int/rec/R-REC-BS.1770/en

The inherited limits are integrated loudness -18 +/- 2 LUFS and true peak <= -1 dBTP.
A binary version and its conformance evidence are release obligations, not values to invent in a text manifest.
All-silent or too-short audio with unavailable integrated loudness cannot receive a fabricated passing value.

For near-silence, use a proposed 480-sample window and 240-sample hop at 24 kHz.
The final short window uses its actual sample count. Do not zero-pad it for classification.
RMS(W)=sqrt(sum(x_i^2)/count(W)). dBFS(W)=20*log10(RMS(W)).
When RMS=0, classify the window as silent and store an explicit zero-RMS flag, not a nonfinite JSON number.
A window is near-silent when dBFS <= -50.
Union touching or overlapping near-silent window intervals before measuring their duration.
Keep the original window decisions as evidence.

Digital leading/trailing silence uses exact zero samples. Interior near-silence uses the RMS method.
Unplanned leading/trailing digital silence longer than 1500 ms requires review.
Unplanned interior near-silence longer than 2000 ms requires review.
Exact equality with the duration threshold does not trigger the longer-than rule.
A planned pause is exempt only inside its reviewed expected interval. Measure excess silence outside that interval separately.
A reviewer cannot override corrupt, undecodable, nonfinite, or out-of-contract final bytes.

## Advisory services

Preserve the raw unconstrained ASR result before comparing it with the erroneous surface transcript.
Do not prompt ASR with the corrected script to improve fidelity.
Save each original token and time range. Proposed alignment is not manual phonetic annotation.

For Azure pronunciation advisory calls, cut at reviewed utterance boundaries where possible.
No chunk exceeds the inherited 25-second limit. A longer utterance needs reviewed phrase cuts.
If no valid cut exists, mark the advisory unavailable. Do not truncate a target.
Use 16-kHz mono PCM16 advisory copies and save the transformation from final 24-kHz sample ranges.
Chunk intervals must not overlap by default. If overlap is later approved, deduplicate observations by original subject and final range.
Give each chunk only the reviewed surface text that belongs to its range.
Preserve provider status, confidence, reference scores, and absent fields independently.
Convert Azure 100-nanosecond ticks using exact integer ratios, then map to the final audio clock.
Do not mistake ticks for milliseconds. Keep raw values and offsets.
NoMatch, missing scores, and failed calls produce typed unavailability rather than zeros.
No advisory score can fill observed_ipa. That field requires actual phonetic evidence.
