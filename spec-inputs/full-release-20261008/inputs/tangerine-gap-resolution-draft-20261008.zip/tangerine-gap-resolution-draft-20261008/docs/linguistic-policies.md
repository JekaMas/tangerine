# Linguistic policy proposals

GAP-014, GAP-017, GAP-028, GAP-035, GAP-036, and GAP-047 require scoped approval.
No text in this file records a linguistic expert approval.

## Aliases

The proposed alias registry covers all 122 historical leaf IDs and 16 ancestor IDs.
It contains candidate English and Russian terms, not a fabricated set of teacher answers.
Preserve the existing category definitions and ID paths.
Build an inverted alias map after NFC, whitespace collapse, and case folding.
If multiple nodes share a normalized alias, return all candidates with ambiguous_alias.
Generic labels such as number or agreement need context or a qualified term before narrow classification.
Do not infer the most favorable leaf from the key.
The registry's structural completeness does not establish linguistic accuracy.

## Judgment compatibility

| Status label | Permitted judgment | Required public/evidence condition |
|---|---|---|
| unequivocal_error | true_error or excluded | A supported defect under the declared context; excluded when evidence is insufficient |
| nonstandard_attested | acceptable, true_error, or excluded | true_error only for a disclosed explicit target or context conflict |
| contextually_inappropriate | true_error or excluded | Public audience, task, relationship, and the relevant mismatch |
| target_form_mismatch | true_error or excluded | The target form is disclosed before the attempt |
| marked_naturalness_issue | acceptable or excluded | A preference alone does not create a true error |
| acceptable_variant | acceptable or excluded | Evidence supports permission under the disclosed context |
| decoy_non_error | acceptable or excluded | The designated control is genuinely permitted |

The taxonomy ID does not determine the judgment by itself.
A declared explicit target does not make every other form an error unless the task actually requires that form.
A hidden en-US preference cannot penalize permitted en-GB speech.
A source corpus accent label is not evidence of communication breakdown.

## Linguistic audit

The proposed prompt and schema are separate artifacts.
For no_findings, findings and missing_input_fields must both be empty.
For findings, at least one finding is required and missing_input_fields must be empty.
For insufficient_input, at least one missing input field is required.
For an utterance finding, the span and quote must identify the same supplied surface text.
For public_context, span and quote are null and context_field names a supplied field.
For a planned_unit, subject_id must exist in the candidate. A span, when present, must belong to its utterance.
The candidate hash must equal the input hash.
No outcome establishes audio correctness or permits publication.

## Token and disfluency procedure

Use the exact reviewed spoken transcript, not the corrected script or raw ASR hypothesis.
Annotate completed lexical tokens, partial-word fragments, and nonlexical filled pauses separately.
Count completed lexical tokens, including each completed repetition.
A contraction is one token. A written apostrophe is not expanded for this count.
Expand numeric text to its actually spoken word sequence before token counting.
Preserve punctuation and source spans, but do not count punctuation tokens.
A partial-word fragment and a nonlexical filled pause do not enter the lexical numerator.
Their intervals remain available for the separately reviewed event count.

A repeated sequence, abandoned start, or repair episode has one event ID and one minimal supporting interval.
Two independent episodes have separate IDs even when their taxonomy labels match.
Overlapping labels for one episode do not increase disfluency density.
A reviewer must distinguish a task-relevant disruption from an ordinary permitted hesitation.
Preserve ordinary fillers as events with error_eligible=false where annotation records them.

Clip speech intervals to the final audio domain only after rejecting out-of-range annotations.
Reject negative or inverted intervals. A zero-duration speech interval is invalid.
Sort intervals by start and end. Merge overlapping or touching intervals.
The active speech duration is the length of that union.
The elapsed span starts at the first lexical onset and ends at the last lexical offset.
Exclude leading and trailing non-speech. Include internal pauses in elapsed speech rate.
If no complete lexical tokens or valid span exists, return no_opportunities rather than divide by zero.

## Prosody methods

The numerical method is a proposal, not a measured qualification result.
Use a pinned Praat binary and the raw autocorrelation method.
The documented legacy parameter defaults include floor 75 Hz, ceiling 600 Hz, silence threshold 0.03, and voicing threshold 0.45.
The proposed method uses a 0.01-second step and records every parameter explicitly.
Keep per-case reviewed floor/ceiling overrides in the method manifest. Never change them after seeing a teacher answer.
Source: https://www.fon.hum.uva.nl/praat/manual/Sound__To_Pitch__ac____.html

For retained voiced frames, let p(t)=12*log2(F0(t)/100 Hz).
A frame without a reliable voiced F0 has no pitch value, not zero semitones.
A reviewer can exclude a tracking error only with a recorded reason and the original frame retained.
If no valid numerical evidence remains, use unavailable or categorical human evidence.

| Feature | Unit/value | Method | Missingness |
|---|---|---|---|
| lexical_stress | Reviewed stressed syllable index or indices | Human phonetic annotation on named word syllables | Missing syllable segmentation or uncertain stress |
| nuclear_stress | Reviewed prominent token/span | Human annotation within the stated phrase | Ambiguous phrase or prominence |
| f0_range_semitones | Semitones | max(p)-min(p) over retained voiced frames | No reliable voiced interval |
| f0_slope_semitones_per_second | Semitones per second | Sum((t-mean(t))*(p-mean(p)))/sum((t-mean(t))^2) | Fewer than two distinct voiced frame times |
| syllable_duration_ratio | Dimensionless ratio | Named numerator syllable duration / named denominator syllable duration | Missing boundaries or zero denominator |
| rhythm | aligns_with_target, does_not_align, uncertain | Human judgment against the reviewed explicit timing/rhythm target | Target criterion absent |
| boundary | Boundary token/sample location and permitted type | Human phrase-boundary annotation | Boundary remains uncertain |
| weak_form | weak, strong, uncertain, not_applicable | Human observation of the named token | Token or target not identifiable |
| linking | present, absent, uncertain, not_applicable | Human observation of the named segment boundary | Boundary not identifiable |
| assimilation | present, absent, uncertain, not_applicable | Observed segment sequence and human evidence | Observed segments uncertain |
| elision | present, absent, uncertain, not_applicable | Human observation of expected versus realized segment | Segment evidence uncertain |

A categorical judgment is not a numerical threshold result.
An approved target can require a different pattern in a different public context.
These labels do not make ordinary weak forms, linking, or elision mandatory in every sentence.

## Gold count procedure

Count asset_id, stimulus_id, target_observation_id, contrast_pair_id, and control_id separately.
An asset is the final byte sequence. A stimulus is the particular complete presented item with public context.
For the inherited floor, designate exactly one leaf for each counted stimulus.
A multi-target item can support secondary observations but cannot satisfy six independent stimuli for many leaves at once.
A reused final audio hash cannot add an independent floor stimulus.
Keep both members of a contrast pair in one split and one pair family.
Use three independently authored families for the three splits.
For a permitted-variant leaf, both pair members remain permitted.
Record that pair as a variant contrast, not as an error-negative pair.
Report all count categories independently. The floor is not a claim of statistical sufficiency.
