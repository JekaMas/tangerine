# Source import proposal and limits

The source inventory remains the full inventory in the supplied gap report.
The decisions for EFCAMDAT, the Doubao study, Moodrick, and NIR remain pending.
This package acquired no corpus bytes and obtained no source-owner permission.

## Release manifest

A source release manifest contains source_id, release_id, upstream URI, actual acquisition time, and raw license/README hashes.
It enumerates every expected and acquired component, partition, member path, size, and observed SHA-256.
Record source-declared counts separately from observed counts.
Define a count unit for every total: files, utterances, speakers, essays, annotations, raters, tokens, or edits.
An import report records accepted, quarantined, rejected, and unavailable component counts.
For each parsed collection, require parsed_total = accepted + quarantined + rejected.
An absent supplied component is missing, not a rejected record with fabricated content.

A permission record states the actual grant, identity of its source, intended uses, expiry, transfer conditions, and revocation status.
Separate local research, local product use, provider transfer, training, redistribution, and publication.
Access to download does not automatically authorize every use.
Unknown rights block the affected use. They do not become assumed consent.

Each transform names input/output hashes, parser/version, method/options, and a scope-preserving category map where used.
Retain raw labels and field names even when the project has no equivalent category.
Unknown or ambiguous mappings remain unclassified. Do not choose a narrow project leaf with an LLM.
A source record and a reviewed user exercise remain different objects.

## SpeechOcean762

The public OpenSLR entry describes the source and offers release files.
Source: https://www.openslr.org/101/

The required current inventory includes train/test files, speaker metadata, aggregate scores, detailed ratings, and all five raters.
Keep utterance, word, and phone level records separate.
Preserve each raw score with its source scale and rater identity. A missing score is not zero.
Do not recompute a source aggregate by guessing its averaging rule.
Record an aggregate/detail mismatch as a finding until the release documentation establishes the rule.
Do not infer a substituted phone from a low accuracy score.
A phone alphabet conversion needs an exact versioned mapping. Keep uncertain or inserted-phone markers unchanged in raw data.
The complete selected-release field/scale grammar still needs its actual documentation and files.
This proposal does not mark GAP-040 closed by naming those obligations.

## L2-ARCTIC v5

The official source distinguishes 24 read-speech speakers and the v5 suitcase extension with 22 speakers.
It distinguishes forced alignment from manually corrected annotations. Its published license is CC BY-NC 4.0.
Source: https://psi.engr.tamu.edu/l2-arctic-corpus/

Include README, license, prompts, recordings, transcripts, automatic TextGrids, manual annotations, and the suitcase components.
Preserve the original sample clock and raw TextGrid bytes.
Parse tier identity before extracting intervals. An unknown tier enters quarantine instead of being treated as a phone tier.
Preserve CPL/PPL, s/a/d, err, and star markers as source labels until the exact v5 definitions and mapping are supplied.
An uncertain marker cannot become an observed narrow IPA symbol or a manually verified project unit.
Keep common script families linked across speakers for leakage grouping.
Exact tier grammar and approved conversion tables remain required before full faithful ingest can pass.

## W&I+LOCNESS and FCE v2.1

The official BEA page describes M2 source sentences, edit offsets, annotator IDs, and noop handling.
It states that these source releases have non-commercial use conditions.
Source: https://www.cl.cam.ac.uk/research/nl/bea2019st/

A block starts with its original S line. Keep its original byte range and token spans.
An A line has start/end token indices, source category, correction string, two historical fields, and annotator ID.
Preserve the historical fields rather than erase them during import.
Use half-open token spans. An insertion has start=end. A noop has its special negative sentinel and does not index the sentence.
Do not apply edits from different annotators together.
Within one annotator, apply nonoverlapping edits from the largest start index backward.
For same-position insertions, use the reverse source-line order during backward application so the final text preserves source order.
Conflicting replacements or undeclared overlaps remain unresolved. Do not choose the shortest correction.
Store the exact token-to-codepoint correspondence from the original S text.
A corrected reconstruction is a derived record, never the original source.
Preserve UNK, Um, detection-only labels, and unavailable test labels without guessed repairs.
An ERRANT category maps only through an approved explicit map. Raw categories remain available when no map exists.
Keep FCE and W&I+LOCNESS release identities, licenses, partition metadata, and group IDs separate.
Complete release metadata and a reviewed narrow-category map still need source integration.

## Sources without supplied data contracts

For EFCAMDAT, a discovery record is not full second-release XML or a separately versioned derivative.
For Doubao, paper participant counts are not acquired recordings.
For Moodrick and NIR, public product text is not a licensed private answer bank.
Do not invent release IDs, file lists, hashes, participant IDs, or permissions for those sources.
An explicit research-only scope decision can change the current release obligation.
It must retain the fact that the historical data obligation was not fulfilled by acquisition.

## Leakage and full-source claims

Full raw acquisition, faithful normalization, usable rights, and qualified gold are separate statuses.
One cannot substitute for another.
Preserve all acquired raw components even when only some have permitted derived uses.
Use explicit blocked_use status for a prohibited transform or provider transfer.
A large connected group stays in one project split. Preserve the source benchmark split as distinct metadata.
Do not make a holdout by dropping speaker or script links.
No all-sources-acquired or gold-complete claim is supported by this package.
