# Local runtime and storage proposal

This document fills engineering rules without adding accounts, tenants, or a public API product.
These rules are candidates for the current repository, not an applied migration.
The operator supplies provider keys. The release supplies images, schemas, policies, and internal defaults.

## Request protocol

All browser operations use same-origin `/api/v1` calls through the web service.
The API and storage ports remain private to the container network.
A browser write uses JSON, an allowed Host and Origin, and a revision precondition when it edits mutable state.
Reject cross-origin writes. Do not use local mode as a claim of security against the machine owner.
A private processing-stage credential is not a user account or role.

Every error has code, operation_id, message, retry_kind, and safe_details.
The retry kind is none, retry_same_answer, retry_feedback_only, or operator_action.
Do not include provider payloads, keys, raw evidence, or secrets in safe_details.

Require an Idempotency-Key for externally costly or state-creating writes.
Scope it to workspace=local, route operation, and target ID.
Store the request hash before the side effect. The same key with a different hash returns 409.
A repeat after success returns the same saved result identity.
An active matching operation returns 409 operation_in_progress with its status URL. Do not start a second worker.
Status reads inspect saved state only. They never resume provider work.

A mutable record has revision as an increasing integer. Require If-Match for edits and state transitions.
A stale revision returns 412. A disallowed state returns 409.
A malformed body returns 400. A valid-shaped body with invalid domain values returns 422.
An oversized request returns 413 before a provider call. A saved answer is never truncated.
A missing known object returns 404. A denied disclosure stage returns a safe 409 or 403 without hidden fields.

## Operation inventory

This inventory specifies the existing activities. The current source must supply exact payload schema bindings.
The payload binding step is not complete in this proposal.

| Method | Path | Effect |
|---|---|---|
| GET | /library | Read only eligible case projections with a cursor |
| POST | /blueprints | Store a typed blueprint revision |
| PUT | /blueprints/{id} | Save a revised draft with If-Match |
| POST | /blueprints/{id}/generate | Call the configured generator and save the candidate |
| GET | /cases/{version}/prepare | Read the preparation projection |
| POST | /cases/{version}/audit | Execute the advisory linguistic audit |
| POST | /cases/{version}/render | Synthesize and save exact audio plus its receipt |
| POST | /cases/{version}/measure | Calculate the audio/advisory evidence |
| POST | /cases/{version}/review-records | Create a person-bound blind review record, not an account |
| PUT | /review-records/{id}/observations | Save a draft independent observation set |
| POST | /review-records/{id}/submit-blind | Freeze observations before disclosure |
| POST | /review-records/{id}/disclose-key | Record the key-disclosure event and return the post-key projection |
| POST | /review-records/{id}/decision | Save the person's explicit final decision |
| POST | /cases/{version}/publish | Enforce publication guards and commit the transition |
| POST | /cases/{version}/quarantine | Block new attempts and affected final commits |
| POST | /cases/{version}/retire | Stop new assignment under the selected policy |
| POST | /attempts | Freeze the exercise and component policy, then create started_at |
| GET | /attempts/{id} | Return the state-specific projection |
| GET | /attempts/{id}/media | Stream permitted audio with Range support |
| POST | /attempts/{id}/playback-events | Save deduplicated descriptive events |
| POST | /attempts/{id}/submit | Freeze the answer, then evaluate synchronously |
| POST | /attempts/{id}/retry | Resume eligible stages explicitly with the original answer |
| GET | /results/{id} | Return the permitted final or provisional result |
| POST | /results/{id}/feedback-retry | Retry only commentary when GAP-027 permits it |
| POST | /disputes | Save a disputed decision and its actual supporting text |
| POST | /disputes/{id}/resolve | Append an evidence-backed resolution |
| POST | /attempts/{id}/result-revisions | Reconsider a selected attempt under an approved key mapping |
| POST | /imports | Import a declared source release within permissions and resource bounds |
| GET | /imports/{id} | Read the saved component reconciliation report |
| GET | /configuration | Return nonsecret supplied configuration and key-presence flags |
| PUT | /configuration | Apply a versioned permitted change, never a silent provider fallback |
| POST | /maintenance/reconcile | Inspect and resolve local metadata/object inconsistencies explicitly |
| POST | /maintenance/delete | Apply a confirmed deletion plan and its permission guards |

A cursor encodes the last `(created_at,id)`, filters, and snapshot boundary.
Sort by `(created_at,id)` ascending. Reject a cursor with different filters.
A cursor is an opaque encoding, not an authorization token.
Default pagination is a proposed 50 records, maximum 200. Confirm compatibility with the current UI contract before activation.
Every list uses a field allowlist. Do not serialize domain records then hide fields in the UI.

## Durable entity groups

Use immutable payload records plus normalized relational reference tables.
A payload hash does not replace a foreign key or a scope check.
For every record, store workspace_id=local, id, schema version, payload hash, and created_at.
Mutable state additionally stores revision. Published payloads do not accept UPDATE.
Use text for externally supplied existing IDs, not an implicit UUID migration.
New processing operations use server-generated UUIDs. Do not reuse actor IDs as operation IDs.

| Entity | Required references and constraints |
|---|---|
| Blueprint revision | Blueprint family, parent revision, profile/policy hashes |
| Case version | Blueprint revision, taxonomy version, public context, immutable content hash |
| Unit | Composite unique `(case_version_id,unit_id)`, primary leaf, exact judgment |
| Correction option | Composite unique `(case_version_id,unit_id,option_id)` |
| Proposition | Exact parent option or unit-rationale scope, required/forbidden class |
| Rationale | Unit, case version, language, reviewed text, evidence references |
| Audio asset | Unique storage key, SHA-256, byte count, sample profile, durable state |
| Case asset relation | Exact case version, asset ID, purpose, reviewed final hash |
| Evidence | Case version, final asset hash, typed subject, actual origin, method version |
| Person | Local attested person identity, no authentication credential |
| Qualification | Person, evidence asset, stated scope, issuer expiry if present |
| Blind review | Person, case version, audio hash, exposure status, frozen observation hash |
| Disclosure | Blind review, disclosed key version/hash, timestamp |
| Final review | Person, frozen pre-key review, exact final key/audio hashes, decision |
| Attempt | Case version/hash, started_at, frozen components, state, revision |
| Answer | Attempt, original UTF-8 hash and bytes, submitted_at, immutable after submission |
| Evaluation operation | Attempt, lease epoch/token/expiry, global deadline, binding hash |
| Stage receipt | Evaluation operation, stage, exact input hash, provider profile hash, status, usage |
| Semantic result | Attempt, extraction/map/audit hashes, normalized decision set hash |
| Score result | Semantic result, policy hash, exact fractions and raw statistics |
| Feedback | Result, language, origin, rationale references, status |
| Dispute | Original result/claim or unit, actual concern, evidence, state |
| Result revision | Original attempt, parent result, approved unit mapping, new result |
| Source release | Exact source/release identity, manifest, selected components |
| Permission | Source/person scope, permitted uses, provenance, expiry/revocation |
| Import record | Release, parser/version, raw locator, normalized record, disposition |
| Transform | Exact input/output hashes, operation/version, permitted use |
| Split component | Frozen member IDs, relation evidence, assigned split |
| Audit event | Operation, local actor attestation where applicable, affected IDs, reason |
| Idempotency record | Unique `(workspace,operation,target,key)`, request hash, result ID |
| Playback event | Unique `(attempt,event_id)`, final asset, accepted server time |
| Deletion record | Exact subjects, authorization, tombstone links, backup obligations |
| Backup manifest | Snapshot, schema/release hashes, included asset hashes, deletion epoch |

Use composite foreign keys for unit, option, rationale, and evidence scopes.
Index each referencing field and `(state,updated_at)` for foreground recovery queries.
Reject cross-case links even when the target ID exists.
Use RESTRICT for historical references. Do not cascade-delete scores or evidence from a case edit.
A permitted erasure preserves a minimal reference tombstone where lawful. It does not pretend the missing payload still exists.
The current artifact columns and migration order remain required integration work.

## Database and object consistency

No distributed transaction is assumed between PostgreSQL and MinIO.
Use a durable asset state of reserved, uploaded, verified, linked, or abandoned.
Allocate a unique object key from the server asset ID. Never overwrite an existing asset key.
In one DB transaction, reserve the asset identity and operation record.
Upload under that key and stream a SHA-256 calculation.
Read the stored object back and check byte count and SHA-256. An ETag is not a SHA-256 proof.
Record verified only after this read succeeds.
Link the verified asset to its exact owner in one DB transaction with the audit event.
Only linked assets can enter ordinary media projections. Review preparation can inspect its explicitly linked candidate assets.
A content-state update cannot change the bytes of the linked asset.

| Crash boundary | Recovery on explicit reconcile or retry |
|---|---|
| Reservation committed, no object | Keep reserved or mark abandoned after an explicit decision |
| Partial upload, no verified receipt | Abort the upload or discard the candidate object; never expose it |
| Full upload, DB not updated | Read bytes and hash, then complete the same reservation if its owner/revision still matches |
| Verified object, link transaction failed | Link only to the original valid owner. Otherwise mark abandoned |
| Link committed, HTTP response lost | Read the idempotency result and return the original asset ID |
| Existing key with different bytes | Integrity failure. Quarantine affected references and do not overwrite |

No startup task calls a paid provider to repair a missing artifact.
Orphan cleanup is an explicit local maintenance action under the retention policy.

## Attempt execution and recovery

Create started_at when the server commits the explicit start operation, not when the browser claims playback began.
Opening another browser tab for the same attempt does not reset started_at.
At submit, validate the input and commit the exact answer before an external call.
Freeze the case, key, components, policies, prompt hashes, schemas, and profile configuration.

Acquire a 300-second lease with an increasing epoch and a random token.
The evaluation request has a 270-second total deadline from lease acquisition.
Every stage receives the remaining deadline. Never restart the global clock for a stage retry.
Before commit, compare state, revision, epoch, token, expiry, global deadline, and case eligibility in the same transaction.
A late provider response cannot overwrite a newer operation.

| State | Allowed action | Result |
|---|---|---|
| Open, no submitted answer | Submit once | Frozen answer and evaluating state |
| Evaluating with active lease | Read status | No new provider work |
| Evaluating with expired lease | Explicit retry | New epoch, same answer and compatible frozen bindings |
| Evaluation failed | Explicit retry | Reuse eligible successful stages, rerun only failed/unperformed work |
| Review required | Review resolution | Preserve answer and pending evidence |
| Complete | Read result | No semantic rerun under the same operation |
| Complete with feedback failure | Explicit feedback retry | Same score, separate feedback receipt |
| Any state with revoked use | Safe read/deletion workflow | No prohibited new transfer or evaluation |

A retry preserves successful stage results only when every input and configuration hash matches.
After a semantic disagreement, retry is not a method to sample a more favorable answer.
A changed model or key requires an explicit new evaluation/revision, not cache reuse.
A browser disconnect cancels in-flight work when possible. Preserve completed receipts and the saved answer.
On the next explicit read, an expired incomplete lease appears interrupted. Reads do not launch work.

## Retries and cost

Count transport attempts separately from candidate generation and render attempts.
Allow at most one transport retry across one evaluation operation, not one retry in every layer.
Disable SDK automatic retries when the application owns this budget.
A 429, 502, 503, or 504 is eligible only when the global retry budget and deadline permit it.
A connection failure before any request bytes were sent is eligible under the same limit.
After an ambiguous disconnect, do not automatically resubmit a potentially billed call without provider idempotency evidence.
Do not retry invalid JSON, a refusal, an incomplete response, a semantic mismatch, or a wrong schema to seek a better answer.
For an eligible retry, use Retry-After if valid. Otherwise wait one second.
Do not retry if the delay and next permitted stage timeout cannot fit before the deadline.
An explicit user retry is a new evaluation operation with its own saved usage, not free work.

Estimate input capacity using the exact provider tokenizer or a verified conservative bound.
If no safe bound exists for a profile, block oversize-sensitive operation until qualification.
Do not use an average characters-per-token estimate as a guaranteed upper bound.
Count reasoning tokens in the output budget where the provider does so.
Refuse oversized data with exact lengths and the violated limit. Keep the original answer.

## Backup and restore

Backup is an explicit foreground maintenance operation.
Enter a write barrier and stop new costly operations. Let active operations finish or cancel them explicitly.
Freeze one metadata snapshot and its complete asset reference inventory.
Export the database, then all referenced immutable assets and private historical evidence.
Store each byte count and SHA-256 in the manifest. Record schema, migration, policy, prompt, and provider-profile hashes.
Record outstanding deletions and revocations in a separate required manifest section.
Do not put provider keys or internal service passwords in the content archive.
Protect the backup as personal data. Its actual encryption/key handling must match the current release contract.

Restore into a fresh temporary environment. Do not overwrite an existing installation.
Check the manifest and bytes before application startup.
Check schema compatibility and migrations. Apply deletions and revoked-use guards before serving media.
Verify all required references. A partial restore cannot become ready.
Switch to the restored data only after the operator confirms the successful check.
On failure, keep the original environment unchanged and return the exact failed component.

## Startup and release

The launcher detects amd64 or arm64 and selects a qualified release profile.
It reads the supplied manifest. It does not infer image names or use latest tags.
On first use, create internal secrets from the operating system random source and persist them privately.
On restart, reuse those secrets. Never regenerate a DB password merely because a container restarted.
Rotate secrets as an explicit operation with rollback and connectivity checks.
Start storage, complete migrations, and create the private bucket before declaring API readiness.
An empty real library is a valid startup state. Do not seed invented exercises.
Missing provider keys disable the affected live action with an exact configuration error.
Stored approved playback remains usable without a live provider call.
Keep unresolved image digests as release blockers. Never fabricate them.
