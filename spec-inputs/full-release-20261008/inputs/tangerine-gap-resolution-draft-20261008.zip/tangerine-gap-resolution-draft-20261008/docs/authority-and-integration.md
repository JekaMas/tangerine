# Authority and integration

The current user request and its two supplied reports define this revision's scope.
The reported local commit is 203c1f1. This package does not contain or verify that commit.
The connected repository search did not locate the current Tangerine repository.
The historical v6 ZIP is available and was inspected for formulas, category IDs, and old contracts only.
Do not replace the current repository with v6 or with this proposal package.

The source order is:

1. The user's explicit current decisions.
2. The current simple-local scope and active schemas after they are supplied.
3. Individually approved resolutions in this package.
4. Historical artifacts only where the active authority map explicitly preserves them.

A report of a missing definition is not that definition.
The three removed concepts remain removed: accounts, access roles, and tenants.
A processing stage is not an access role. A person record is not an account.
Private same-origin transport is not a public API product.
Do not switch the selected DeepSeek profile back to the old OpenAI default because v6 named it.

Before integration, obtain the current source archive without secrets, local data, or virtual environments.
Required content includes docs, domain, contracts, prompts, OpenSpec, audit records, deployment files, and actual source code if present.
Record the supplied commit and file hashes. Do not treat a local filesystem path in a report as accessible bytes.

For each GAP, map the exact current artifacts, proposed edits, dependent decisions, and later evidence obligations.
Keep the full original gap text. Mark it closed only after its closure criterion is met by integrated artifacts.
A draft or an approval alone does not prove implementation or provider behavior.
New schemas need an explicit version. Do not mutate a published schema version in place.
Changing a schema, prompt, alias map, correction policy, or key invalidates the relevant stage cache.
A cache key includes the exact stage inputs, profile, model identifier, prompt/schema hashes, and policy references.
A key change never silently reuses a previous semantic result.

This package contains no decision approvals, fabricated identities, invented audio, or provider test results.
Every recommendation remains proposed until its GAP receives an explicit decision.
Engineering drafts remain candidates until reconciled with the current source.
