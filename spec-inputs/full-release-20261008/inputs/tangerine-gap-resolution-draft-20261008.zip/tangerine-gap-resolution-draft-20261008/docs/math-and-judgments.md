# Exact math and semantic decisions

This is an engineering proposal for GAP-013 and GAP-018 through GAP-026.
The current repository must supply the final schema and policy versions before integration.
The 42 formulas in the reference registry remain unchanged.
A correct formula does not establish the truth of a model judgment.

## Identity and text

Store the exact answer as UTF-8 bytes. Reject invalid UTF-8 and isolated surrogate values.
Do not normalize the stored answer. Compute its SHA-256 from those original bytes.
Offsets count Unicode codepoints. They do not count UTF-8 bytes or UTF-16 code units.
Use half-open intervals `[start,end)`. Require `0 <= start < end <= codepoint_length` for a nonempty quote.
A quoted string must equal the exact slice. Do not search for a nearby replacement.

A clause ID is `clm_` plus SHA-256 of a length-prefixed tuple.
The tuple contains the answer hash, extraction-contract hash, kind, start, end, and exact quote.
Encode each field as UTF-8 with its unsigned 64-bit big-endian byte length first.
Use the same algorithm for a normalized group, with sorted member IDs as separate fields.
Keep all 256 hash bits. Do not use an array index as the identity.
Sort clauses by start, end, kind, then ID. An ID tie with different content is an integrity error.

Classify every non-whitespace answer interval as a substantive clause, an attachment, or non-assertive text.
Preserve unparsed intervals separately. An uncovered non-whitespace interval prevents a complete-extraction claim.
Mechanical coverage cannot prove that a model classified the text correctly.
Semantic omission needs the independent annotation and acceptance process.
Cross-sentence correction attachments retain their separate source spans and explicit parent links.
Overlapping spans need an explicit containment or attachment relation. Unexplained overlaps require review.

## Event units

One occurrence at one reviewed location is one unit unless independent repairs are necessary.
A repeated word at a different location is a different opportunity.
A multi-utterance discourse event has one unit with multiple ordered evidence spans.
Several labels for the same repair do not create several opportunities.
Apply the most specific supported leaf. Keep other supported labels as secondary.
If two equally specific primary labels remain valid in different domains, obtain adjudication before publication.
An unresolved unit boundary cannot enter a final denominator.

## Fragment normalization

Keep the original clauses. Never replace them with a synthesized favorable answer.
Remove exact duplicates from counting only when stance, location, correction, and rationale are equivalent under approved rules.
Point each duplicate directly to the earliest nonduplicate representative. Reject self-links and cycles.
A retraction must explicitly identify an earlier claim or an unambiguous earlier assertion.
Do not infer retraction from a later contradiction. Require all retraction links to point backward in source order.
Resolve a valid retraction chain before consolidation. Keep the whole chain in evidence.
Combine compatible fragments only when they describe the same event and do not contradict each other.
If competing repairs remain endorsed, return review_required. Do not select the last or best repair.
If a broad statement could refer to multiple occurrences, do not assign it to all occurrences.

## Decision truth table

| Stance and supported subject | Decision | Unit | Count effect |
|---|---|---|---|
| Error assertion on a true error | matched_error | Existing true-error ID | TP once |
| Error assertion on a designated permitted control | false_positive | Existing control ID | FP once and DF once |
| Resolved unsupported error assertion elsewhere | false_positive | Null | FP once |
| Explicit acceptance of a permitted control | confirmed_acceptable | Existing control ID | DA once |
| Explicit acceptance of a true error | wrong_acceptance | Existing true-error ID | FN and wrong status judgment |
| Question, example, or metacomment without an error assertion | ignore | Null unless a justified non-counting reference exists | No TP or FP |
| Ambiguous location, contradiction, or possible key defect | unresolved | Exact known subject or null | Withhold final aggregates |
| Exact duplicate of a resolved representative | Same supported decision, duplicate link | Same subject | No additional contribution |

An excluded unit contributes neither G nor D. A substantive assertion about it still needs an explicit disposition.
Do not silently discard a claim that could change a result.
A possible off-key error is unresolved, not a false positive by default.
Wrong category labels do not remove valid detection credit.

## Correction and explanation conversion

Do not accept a model-supplied fraction.
For an eligible unit, choose only an existing reviewed correction option.
The model can identify satisfied required propositions and present forbidden propositions.
Validate every proposition ID against that exact option and case version.
A proposition outside the option is an invalid output, not a new rubric item.

Let R be the set of required propositions. Let S be the satisfied subset.
Let B be the present forbidden propositions. Use unique IDs in each set.
For supplied work, q is zero when B is nonempty. Otherwise q is `|S|/|R|`.
Require `|R| > 0` for a scored option. Missing work has q=0.
An exact approved alternative earns full credit only when the complete endorsed correction contains no conflicting extra assertion.
A plausible novel alternative requires review. It cannot enter the accepted alternatives automatically.
If several candidate options produce a materially different interpretation or credit, require review.

For explanation, option_id must be null. Use the unit's reviewed rationale proposition sets.
An extra unsupported substantive rationale assertion requires a decision. Do not ignore it because another clause is correct.
An explanation or correction not supplied by the teacher cannot receive credit.
Derive accepted for q=1, partial for 0<q<1, rejected for supplied q=0, and not_supplied for missing work.
Use unresolved only with an explicit permitted cause. Do not publish final scores for unresolved relevant judgments.

## Mapper and auditor comparison

Both requests receive the same frozen extraction, case, registry, and configuration.
The second request must not receive the first output.
Join by claim ID, not list position. Reject missing and duplicate claim IDs.
Compare decision, target unit, duplicate/retraction representative, category, correction option, proposition sets, status, and unresolved reason.
Read stance from the shared extraction. If the stage challenges stance, record an unresolved issue rather than silently replace it.
Sort set-valued IDs before comparison. Ignore ordering within genuine sets.
Different valid supporting evidence sets are harmless only if both support the same exact subject and decision.
A changed target, option, proposition set, category, or relevant reason requires review.
Free-text notes cannot override a comparison failure.

## Exact values

Use integer arithmetic for counts and rational arithmetic for scores.
Transport rational numerator and denominator as canonical decimal strings.
Reduce with gcd. The denominator is positive. Represent zero only as 0/1.
Use decimal strings for accumulated counts that can exceed a browser safe integer.
Reject noncanonical signs, leading zeroes, negative counts, infinity, and NaN.
The proposed rational text limit is 4096 digits per magnitude.
If an operation exceeds that bound, return numeric_capacity_exceeded. Preserve the source evidence.
Do not clip a value or round it to fit the bound.

For a ratio r=n/d, the one-decimal percentage display uses:

```text
T = floor((2000*n + d)/(2*d))
text = integer_part(T/10) + '.' + last_decimal_digit(T) + '%'
```

This display formula applies to nonnegative ratios. The stored fraction remains unchanged.
For a signed auxiliary value, round the magnitude half-up and restore the sign.
For a composite C already on a 0..100 scale, use:

```text
C = 100 * sum(w_i * n_i/d_i) / sum(w_i)
T = floor((20*C_n + C_d)/(2*C_d))
```

Store C as a reduced rational. Never derive C from displayed component percentages.
Use only enabled components with structural opportunities.
Missing requested work is zero credit, not an unavailable component.
No enabled opportunity produces a null composite.
An unresolved score-relevant decision produces a null final composite.

## Auxiliary populations

Raw agreement compares the same nominal label slots from two pre-adjudication human submissions.
Use the paired observed slots as N. Report omitted slots and coverage separately.
Abstention is an explicit label. A missing rater response is not an agreement.
Calculate kappa from the observed marginal label counts. N=0 or Pe=1 gives null.
Do not calculate agreement from the post-adjudication unanimous key.
If independently discovered events cannot be aligned without changing their labels, report that event-matching uncertainty separately.

Semantic mapping precision uses correct resolved predicted decisions divided by all resolved predicted decisions.
Spurious resolved predictions remain in the denominator.
Coverage uses resolved eligible human-gold decisions divided by all eligible human-gold decisions.
A silent omission is unresolved coverage, not a reduction in the denominator.
Exact mapping agreement treats an abstention or missing eligible decision as disagreement.
Preserve separate human gold for duplicates, retractions, controls, and non-assertive clauses.

For three repeated evaluations, use every unordered pair of runs on the same eligible inputs.
There are 3*N pairwise comparisons. Report exact matches divided by 3*N.
Repeated abstention can agree but cannot satisfy the separate coverage gate.
Keep a separate strict-correction-verdict population. Do not substitute its sample count for mapping decisions.

WER uses the reviewed surface transcript and the independent ASR hypothesis.
Use a frozen tokenizer and unit-cost Levenshtein distance.
For equal-cost paths, prefer match, substitution, deletion, then insertion.
WER can exceed one. Do not clamp it to a probability range.
For an empty reference, return no_opportunities and retain S/D/I counts.

Elapsed time is submitted_at minus started_at from stored server timestamps.
A clock discontinuity makes the value unavailable. It is not a negative skill score.
Replay count is the number of deduplicated accepted play events. It does not prove listening.
Teacher talk time, spoken teacher pronunciation, classroom management, and real student engagement are not observable in this mode.
Return explicit null fields for those four inherited metrics.

## Feedback references

A detected item references a real normalized decision and unit.
A missed item references the gold unit only. It does not invent a teacher decision ID.
A false-positive item references the real decision and an optional control unit.
A pending item references an unresolved issue and only known subjects.
Every approved rationale names its unit, case version, language, reviewed text, and supporting evidence.
If approved bilingual rationale is absent, return unavailable. Do not invent a translation and label it approved.
An LLM paraphrase is not deterministically proven true by ID membership.
Preserve its origin and review policy. Exact approved text is the deterministic fallback, not a fake provider result.
