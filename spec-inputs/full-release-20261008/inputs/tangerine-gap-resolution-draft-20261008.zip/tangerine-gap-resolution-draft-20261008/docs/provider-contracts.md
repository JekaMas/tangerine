# Provider contract proposal

The current report selects a DeepSeek development profile. Its exact current configuration file was not supplied.
Do not replace it with the historical v6 OpenAI profile.
Do not infer the current model ID from a public model catalog.

## Documented behavior

DeepSeek's Responses API documentation states that developer messages receive user-message treatment.
It provides instructions as a system-level field and supports reasoning.effort=low.
The output budget includes reasoning and visible tokens. A completed response can contain reasoning and message items.
The adapter must select visible message output, not reasoning text.
Source: https://api-docs.deepseek.com/api/create-response/

OpenAI documents a supported subset of JSON Schema for Structured Outputs.
Its strict objects require declared properties and required fields.
A structurally constrained response can still contain a wrong semantic answer.
Source: https://developers.openai.com/api/docs/guides/structured-outputs

These are documentation findings, not live conformance results.

## Trusted instructions

For the proposed DeepSeek adapter, put the trusted stage prompt in instructions.
Put the typed task input in one user message. Do not put trusted instructions in a developer message.
Use reasoning.effort from the frozen profile. Never raise it silently on failure.
For the OpenAI adapter, use the trusted instruction channel defined by its exact frozen profile.
All application text supplied by teachers, corpora, or generators remains untrusted data.
No stage enables tools, browser access, file search, or executable code.

## Stage input boundaries

| Stage | Permitted input | Forbidden input |
|---|---|---|
| Case generation | Blueprint, taxonomy definitions, approved public context, selected capability profile | Private reviewer identity documents |
| Linguistic audit | Candidate, public context, planned key, correction propositions, candidate hash | Claimed observed audio evidence without actual observations |
| Blind extraction | Exact teacher answer and its hash, extraction contract | Transcript, key, gold targets, suggested corrections |
| Mapping | Frozen extraction, permitted case key, exact taxonomy/alias policy, approved evidence projection | New invented teacher claims, unrelated case records |
| Mapping audit | The same frozen input as mapping | The first mapper output |
| Feedback | Accepted result or provisional issue set, approved same-language rationales | Unsubmitted key, private reviewer documents, unsupported repairs |

A stage input DTO needs an exact closed schema in the current repository.
This package supplies the proposed linguistic-audit output, not all missing current input DTOs.

## Response selection

Require a successful HTTP response and completed top-level response status.
Reject incomplete, failed, and in_progress as successful stage payloads.
Reject a refusal or tool call. Keep its safe failure class and private provider receipt.
Require exactly one completed assistant message for the expected JSON stage.
Concatenate only its output_text parts in their stated order.
Do not append reasoning, analysis, summaries, tool arguments, or earlier messages.
A second assistant message or unknown relevant output type is an unsupported response, not a best-effort selection.
Parse exactly one JSON object. Reject duplicate object keys, trailing documents, NaN, and invalid Unicode.
Do not strip markdown fences or repair invalid JSON.
Run the full local schema and all cross-field/domain checks before acceptance.

## Schema projection

Keep the full application schema as the normative acceptance contract.
Record its hash, the wire schema hash, the projection method hash, and each keyword disposition.
Forward type, properties, required, enum, additionalProperties, arrays, and supported references only under the exact provider contract.
Convert const to a singleton enum only where this preserves the application meaning.
Do not remove nullable fields merely to satisfy required-field rules.
When a wire format cannot express an application constraint, keep that constraint in mandatory local validation.
Record that difference explicitly. It is not permission to accept a weaker application payload.
If a supported wire projection cannot be constructed, reject the profile before the call.
Do not assume that OpenAI compatibility proves identical strict-schema behavior in DeepSeek.

The exact per-keyword inventory must be generated from the current active schemas.
No complete current-provider keyword certification is claimed in this package.

## Receipt and cache

A stage receipt binds operation ID, stage, input hash, prompt hash, schema hash, model/profile hash, and returned model identifier.
It also records the actual request/response byte hashes, elapsed time, provider request ID, usage fields, and terminal status.
Store secrets separately. Do not hash a whole secret-bearing request into a public record.
A cached result can be reused only when all semantic inputs and binding hashes match.
Do not reuse a failed, incomplete, disputed, or unvalidated response.
An alias-named provider model can change behind that name. Record this reproducibility limit and qualify changed behavior.
Usage without a provider receipt is unknown, not zero.
