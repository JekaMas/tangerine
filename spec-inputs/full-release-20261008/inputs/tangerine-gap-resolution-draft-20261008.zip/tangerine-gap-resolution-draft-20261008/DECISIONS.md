# Decisions for the local product

These are proposals, not recorded approvals. Reply by GAP ID.
An approval of one GAP does not authorize mocks, fabricated evidence, or unrelated features.
Existing hard scope remains: all error families, all metrics, local containers, provider keys, no accounts, no streaming product flow.

The current repository snapshot is also required for integration. The supplied reports refer to commit `203c1f1` and newer local overlays.

## GAP-002: Result disclosure

**Proposed decision:**

- Before submission, show public context and audio only. Do not disclose the transcript, key, unit count, or target categories.
- After submission, show the whole transcript and key for that exact attempt. Label unresolved findings provisional.
- For a quarantined historical case, keep the stored result and an explicit warning visible. Apply rights revocation before media access.
- Do not expose reviewer personal documents or provider raw responses in the teacher activity.
- The local owner can enter Prepare. The application does not promise secrecy against its owner.

**Decision requested:** Approve whole-transcript and whole-key disclosure after submission, including provisional status labels?

**Other choices:** Show result-linked excerpts only. Specify when full disclosure becomes available.

## GAP-007: Quarantine and retirement

**Proposed decision:**

- Quarantine blocks new attempts and final score commits immediately.
- Save an answer from an already-open attempt, but do not start or finish scoring against a quarantined case.
- Keep provider receipts from an interrupted evaluation. Mark its result review_required, not incorrect.
- Retirement blocks new attempts but permits existing attempts to finish against the frozen case.
- A quarantined version can return to review. It can return to publication only if its bytes and key remain unchanged and review clears the concern.
- A changed key, context, or audio creates a new case version. Rights revocation overrides the retirement exception.

**Decision requested:** Approve this different treatment of quarantine and retirement?

**Other choices:** Block all open attempts on both retirement and quarantine. Allow completion under quarantine with a provisional result; never a final confirmed score.

## GAP-009: Historical result revisions

**Proposed decision:**

- List every affected historical attempt after an approved key correction.
- Reconsider only attempts that the local operator selects explicitly. Do not start a background batch.
- Append a result revision. Keep the original result and the original answer.
- Show the newest completed reviewed revision first, with a visible revision label and access to the original.
- Re-score an original recording only when the correction concerns that same audio. A new recording does not change what a teacher previously heard.
- Require an explicit old-unit to new-unit correspondence. A split or merged unit needs a reviewed mapping.

**Decision requested:** Approve explicit selection of affected attempts rather than automatic rescoring?

**Other choices:** Revise only the disputed attempt. Require separate confirmation of every affected attempt rather than one explicit selected set.

## GAP-011: Human review evidence

**Proposed decision:**

- The local operator attests a person record. It is an attestation, not electronic identity verification.
- Record relevant teaching or linguistic qualifications, or a documented competence assessment. A job title alone is insufficient.
- For acoustic cases, require documented phonetics competence for at least one counted reviewer.
- Two counted reviewers must be different people. Neither can be the author of the case or see the other blind submission first.
- Record conflicts and any prior exposure to the key. Exposed observations cannot count as blind evidence.
- Re-attest independence and competence for each review. Do not invent an expiry date for a credential with no issuer expiry.
- A third qualified person resolves a disagreement. Publication still needs two explicit final approvals of the adjudicated version.

**Decision requested:** Approve these qualification, conflict, and final-approval rules? Who will provide the real reviewer evidence?

**Other choices:** Specify alternative qualification evidence or conflict rules. Two real independent reviewers remain required by current scope.

## GAP-014: Bilingual category aliases

**Proposed decision:**

- Use the proposed registry in domain/category-aliases.proposed.yaml.
- Accept canonical taxonomy IDs, the existing English labels, the proposed Russian labels, and explicitly registered parent terms.
- Normalize with Unicode NFC, whitespace collapse, and Unicode case folding. Do not transliterate, stem, or infer synonyms.
- An alias that maps to multiple nodes stays ambiguous. Do not choose the more favorable node.
- An unknown category does not cancel a valid detection. It does not receive guessed classification credit.
- New aliases need review and a new registry version. Historical attempts keep their old registry.

**Decision requested:** Approve this exact registry as the initial terminology policy, or identify entries to change?

**Other choices:** Keep only canonical IDs and existing unambiguous English labels until the Russian registry receives separate approval.

## GAP-015: Severity and weights

**Proposed decision:**

- Bind minor=1, moderate=2, major=3, communication_breakdown=4. Keep FP weight=1.
- Minor: a local target mismatch with recoverable meaning and no documented change in the core proposition.
- Moderate: a local ambiguity or processing burden that the immediate public context resolves.
- Major: a materially wrong proposition, reference, or communicative force, while an interpretable message remains.
- Communication breakdown: the intended message cannot be recovered in the stated context.
- Require case-specific evidence and reviewer agreement. Do not claim measured listener harm from a hypothetical example.
- Freeze the label and weight before the attempt. Preserve composite weights 45/15/30/10.

**Decision requested:** Approve the fixed label-to-weight mapping and rubric?

**Other choices:** Specify a different mapping or an evidence-based independent-weight policy.

## GAP-016: Difficulty labels

**Proposed decision:**

- Keep all first-release exercises unrated until a separate empirical rating protocol is approved and completed.
- Keep CEFR and target complexity as content metadata, not a measured teacher-task difficulty.
- Retain the schema fields for later ratings. Do not display easy, medium, hard, or expert as measured ratings without evidence.

**Decision requested:** Approve unrated difficulty until a real rating study? This does not remove any error category or metric.

**Other choices:** Enable ratings only after specifying a target population, measurement method, sample floors, cutoffs, and uncertainty.

## GAP-017: Variety and contextual judgment

**Proposed decision:**

- Use explicit_target_form or contextual_appropriacy only when the relevant target or context is visible before the attempt.
- Use intelligibility only with recorded evidence of the relevant communication problem. An accent label is insufficient.
- Treat attested nonstandard or marked language as permitted unless a disclosed target or context makes it a mismatch.
- Record en-US and en-GB as initial named varieties. Other varieties require an explicit reviewed definition, not silent rejection or guessed rules.
- Use register labels informal, neutral, and formal, with explicit task, audience, and relation fields.
- A missing public condition produces excluded or needs_review, not a true error.
- The judgment compatibility table in linguistic-policies.md governs status combinations.

**Decision requested:** Approve the contextual judgment rules? Add required initial named varieties or registers.

**Other choices:** Supply a broader reviewed variety/register registry before publication.

## GAP-027: Feedback-only failure

**Proposed decision:**

- Keep a valid numeric result complete if only the last feedback stage fails.
- Show reviewed stored rationale in the selected language with feedback_status=fallback.
- If reviewed fallback text in that language is unavailable, show the numeric result with feedback_status=unavailable.
- An explicit feedback retry repeats only that stage. It does not change accepted semantic decisions or scores.
- A failed extraction, mapping, or audit cannot use this exception.

**Decision requested:** Approve completed scores with labeled fallback or unavailable commentary?

**Other choices:** Treat feedback as mandatory for completed status, but still preserve the valid numeric result separately.

## GAP-028: Linguistic-audit contract

**Proposed decision:**

- Use the exact prompt in prompts/linguistic-audit.proposed.txt and the closed schema in contracts/linguistic-audit.proposed.schema.json.
- The audit checks context, planned errors, proposed corrections, unintended errors, and unsupported claims.
- Each finding cites a supplied span or context field and uses a fixed finding code.
- The audit cannot invent phonetic observations, add approved alternatives, publish a case, or impersonate a reviewer.
- Treat findings as advisory. Retain the original candidate and send unresolved concerns to human review.

**Decision requested:** Approve the exact advisory prompt and schema in this package?

**Other choices:** Return edits to the prompt or finding vocabulary before activation.

## GAP-032: Hard speech requirements

**Proposed decision:**

- Every explicitly requested voice, target phone, stress pattern, pause, variety, accent, and pace interval is a hard requirement.
- A target WPM request must include a tolerance or an approved profile-defined tolerance. Do not invent a tolerance per case.
- Reject incompatible requests before synthesis. Keep unavailable requests visible as unsupported.
- Do not drop a target, change a voice/provider, or substitute a human recording.
- After the inherited maximum of three render attempts, block that candidate pending a scoped decision.
- An author can mark a property advisory only through an explicit saved case-specific choice. Advisory status is not the default.

**Decision requested:** Approve these hard-versus-advisory rules?

**Other choices:** Name the exact properties that can default to advisory and their tolerances.

## GAP-035: Speech token and interval policy

**Proposed decision:**

- Count completed lexical words in the reviewed surface transcript. Count repeated completed words separately.
- Count a contraction such as do not contracted to one written token as one spoken token. Keep the actual surface form.
- Expand numbers to the words actually spoken before counting. Do not guess an expansion from digits.
- Do not count partial-word fragments or nonlexical filled pauses as lexical word tokens. Preserve them in event annotations.
- A hyphenated spelling does not determine the count. Use the reviewed spoken lexical units.
- Calculate articulation duration from the union of reviewed speech intervals, not from their raw sum.
- Count disfluency episodes only under the reviewed event rules. An ordinary filler or repair is not automatically an error.

**Decision requested:** Approve this tokenizer and event-counting policy?

**Other choices:** Count filled pauses in the speech-rate numerator. Specify which filler classes and retain a separate lexical rate.

## GAP-036: Prosody measurements

**Proposed decision:**

- Use the feature/unit/method table in linguistic-policies.md.
- Use a version-locked Praat autocorrelation method for numerical F0, with explicit per-case pitch floor/ceiling and human review of tracking errors.
- Use semitones relative to 100 Hz for numerical calculations. Estimate slope on retained voiced frames only.
- Use reviewed syllable boundaries for duration ratios. A numeric ratio needs named numerator and denominator syllables.
- Use human categorical annotations for stress, rhythm, boundaries, weak forms, linking, assimilation, and elision.
- A numeric method that cannot measure a case returns unavailable with a reason. Human evaluation still covers that target.
- Requested values and observed values remain different fields.

**Decision requested:** Approve numerical methods where valid and human categorical evidence elsewhere?

**Other choices:** Supply a different exact numerical method or require human-only prosody initially, while retaining all target categories.

## GAP-043: EFCAMDAT scope and intended uses

**Proposed decision:**

- Proposed required ingest scope: full second release only.
- Keep Shatz2020 and Oksuz2025 derivative releases separate. Do not silently use them as the full release.
- Keep acquisition and provider transfer blocked until an actual agreement permits each intended use.
- Retain a source obligation as blocked if the required full release or schema is unavailable.

**Decision requested:** Select second release only or also named derivatives. State intended uses: local research, internal training, commercial product, redistribution, and provider transfer. Supply the actual agreement when available.

**Other choices:** Include the separately versioned derivatives as additional required releases. Explicitly change this source to research-reference-only.

## GAP-044: Doubao participant records

**Proposed decision:**

- Propose research-reference-only scope for the paper until an authorized participant-data release exists.
- Do not require unavailable participant recordings to run the product.
- Keep a historical entry that no study records were acquired.
- Do not claim all historical sources acquired. A scope decision is not acquisition evidence.

**Decision requested:** Approve research-reference-only scope, or keep acquisition of an authorized full participant-data release as a blocking requirement?

**Other choices:** Keep full dataset acquisition required and provide the author-authorized release contract.

## GAP-045: Moodrick and NIR data

**Proposed decision:**

- Moodrick: propose public-comparison-only scope. No private prompts, rubrics, or answer banks enter the corpus.
- NIR: propose public-comparison-only scope. Treat each named NIR product disclosure separately.
- Do not count either vendor as an acquired dataset.
- A future ingest needs a separate actual release, schema, license, and transfer permission for each vendor.

**Decision requested:** Approve the proposed scope for Moodrick and NIR separately, or identify authorized data releases that remain required?

**Other choices:** Keep Moodrick full data acquisition required. Keep NIR full data acquisition required.

## GAP-046: Leakage-safe corpus splits

**Proposed decision:**

- Build connected components over shared learner/speaker, script family, and derivation links.
- Never split a connected component. Keep upstream benchmark labels separately from project splits.
- For original TET-GOLD pairs, give each leaf one independent pair family per split. Keep both members of a pair in that split.
- For external data with no binding upstream split, propose 60/20/20 component allocation by stimulus count.
- Use deterministic SHA-256 ordering with seed text tangerine-split-v1. Save the actual allocation manifest.
- A giant connected component remains whole. Mark infeasible stratification insufficient rather than weaken independence.
- Existing reviewed split assignments cannot change silently when new data arrive.

**Decision requested:** Approve this split policy, including the proposed external-data ratio and seed?

**Other choices:** Specify another ratio/seed. Speaker, script-family, and derivative separation remain unchanged.

## GAP-047: Gold count floor

**Proposed decision:**

- Keep the inherited floor of six distinct stimulus records for each of 122 leaves: at least 732 records.
- Each leaf has one independent contrast-pair family per development, calibration, and holdout split.
- For ordinary error leaves, the pair contains an error realization and a permitted control.
- For acceptable-variant leaves, both members remain permitted in their disclosed contexts. They contrast the relevant permitted forms or contexts.
- Do not relabel a permitted variant as an error. Report error-negative controls and variant contrasts separately.
- One multi-target file can contain many observations, but it counts as one stimulus for one designated leaf in the floor.
- Report audio assets, stimuli, observations, pair families, and controls as separate counts. Shared final audio hashes do not add independent stimuli.

**Decision requested:** Approve this interpretation of the 732-stimulus floor without turning permitted variants into errors?

**Other choices:** Specify a different explicit floor or counterpart rule. This is a scope/policy change, not an implicit engineering correction.

## GAP-051: Retention and deletion

**Proposed decision:**

- Retain published audio, keys, answers, final semantic receipts, and review evidence until explicit deletion or a source/consent restriction.
- Retain unused failed/draft provider payloads for 30 days, unless a dispute places them on hold.
- Retain diagnostic logs for 30 days. Never put answer text, keys, or credentials in diagnostic logs.
- Cleanup occurs only on an explicit maintenance action. Show what it will erase before confirmation.
- Revocation immediately blocks prohibited new use and transfer. Preserve a minimal tombstone and dependency links where permitted.
- Apply a deletion manifest before a restored backup can serve content. Backup copies require their own explicit erasure action.
- Retain the latest three manual backups by default. Confirm erasure of older backups. Do not claim immutable hashes are anonymous.

**Decision requested:** Approve these retention periods and manual deletion rules, or specify different periods?

**Other choices:** Keep all local artifacts until explicit deletion, with no age-based cleanup candidates. Specify another retention schedule for each data class.

## GAP-052: Local resource limits

**Proposed decision:**

- Propose one active costly foreground operation for the local workspace. Reads and stored playback remain available.
- Propose safety limits of 100000 Unicode codepoints per answer and 2000 normalized claims per attempt. Reject oversize input without truncation.
- Propose import limits: 32 GiB compressed archive, 128 GiB expanded bytes, 250000 members, 2 GiB per member, no nested-archive expansion.
- Reject path traversal, links, duplicate normalized paths, and special files. Check free space before admission and during expansion.
- Propose local cost guards of USD 10 per UTC day and USD 100 per UTC month, using versioned tariffs and conservative reservation.
- An unknown charge stays reserved at its upper bound until reconciled. Never interpret missing usage as zero cost.
- These are local guards, not a guaranteed provider invoice ceiling. A priced operation with no finite cost estimate stays blocked.
- Provide explicit bounded configuration changes. Do not remove corpus records to fit an import limit.

**Decision requested:** Approve these engineering safety defaults? State different daily/monthly budgets or import capacity requirements.

**Other choices:** Keep concurrency=1, choose a different cost cap, and specify storage capacity.
